<footer class="footer">
    <div class="container-fluid">
        <div class="copyright">
            &copy; {{ now()->year }} {{ __('by') }}
            <a href="https://github.com/acmachado14" target="_blank">{{ __('Angelo Machado') }}</a> &amp;
            <a href="https://github.com/Iurymartins46" target="_blank">{{ __('Iury Martins') }}</a>.
        </div>
    </div>
</footer>
