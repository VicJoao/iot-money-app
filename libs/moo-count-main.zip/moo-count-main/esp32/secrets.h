#ifndef SECRETS_H
#define SECRETS_H

#define WIFI_SSID     "Universo"
#define WIFI_PASSWORD "angeloarthur"

#define PHONE ""
#define PHONE_API ""
#define CONFIG_EXAMPLE_HTTP_ENDPOINT "192.168.1.4:8000"
#define MAX_HTTP_OUTPUT_BUFFER 2048

#endif